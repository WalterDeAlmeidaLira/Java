package ADO2_POO;

public class FigurasGeometricas {
	protected double area;
	
	public void calculaArea() {
		
	}
}
